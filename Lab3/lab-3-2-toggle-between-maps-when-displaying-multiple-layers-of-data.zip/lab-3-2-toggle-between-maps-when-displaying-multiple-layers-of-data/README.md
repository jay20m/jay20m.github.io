# Lab 3-2 Toggle between maps (when displaying multiple layers of data)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jay20m/pen/eYjMBzW](https://codepen.io/jay20m/pen/eYjMBzW).

