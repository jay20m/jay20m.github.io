// The value for 'accessToken' begins with 'pk...'
mapboxgl.accessToken =
  "pk.eyJ1IjoiamF5MjBtIiwiYSI6ImNsY3FhdThzbzAxdjIzdnAzNzliZmp6NjAifQ.GzpyQziIQ5hP-pNszrIKwQ";

//Before map
const beforeMap = new mapboxgl.Map({
  container: "before",
  style: "mapbox://styles/jay20m/cldaan3v5000d01ruzdcac3ze",
  center: [-0.089932, 51.514441],
  zoom: 14
});

//After map
const afterMap = new mapboxgl.Map({
  container: "after",
  style: "mapbox://styles/jay20m/cldaasf5j006p01pg58zs7hai",
  center: [-0.089932, 51.514441],
  zoom: 14
});
const container = "#comparison-container";
const map = new mapboxgl.Compare(beforeMap, afterMap, container, {});
