# Lab3-1 Swipe between maps (when comparing two maps side by side)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jay20m/pen/eYjMzww](https://codepen.io/jay20m/pen/eYjMzww).

