# Lab 3-3 Filtering data using sliders (useful when there is a temporal dimension in your data)t

A Pen created on CodePen.io. Original URL: [https://codepen.io/jay20m/pen/ZEjxBwv](https://codepen.io/jay20m/pen/ZEjxBwv).

